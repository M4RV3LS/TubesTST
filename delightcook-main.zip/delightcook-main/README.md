# delightcook
Delight cook is a meal kit delivery services app that provides customers with pre-portioned and ready-to-cook ingredients along with easy-to-follow recipes to cook meals at home in the easiest and fastest way without compromising on nutritional quality.
